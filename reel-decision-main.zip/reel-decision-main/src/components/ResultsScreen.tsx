import { Trophy, Crown, Medal, RotateCcw, Star, Frown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "./Logo";
import type { Movie } from "@/data/movies";

export interface MovieScore {
  movie: Movie;
  score: number;
  voters: string[];
}

interface Props {
  results: MovieScore[];
  totalVoters: number;
  onRestart: () => void;
}

const podiumStyles = [
  {
    height: "h-32 sm:h-36",
    bg: "bg-gradient-gold",
    text: "text-accent-foreground",
    glow: "shadow-gold",
    label: "1st",
    icon: Crown,
  },
  {
    height: "h-24 sm:h-28",
    bg: "bg-gradient-to-b from-slate-300 to-slate-400",
    text: "text-slate-900",
    glow: "",
    label: "2nd",
    icon: Medal,
  },
  {
    height: "h-20 sm:h-24",
    bg: "bg-gradient-to-b from-amber-700 to-amber-800",
    text: "text-amber-50",
    glow: "",
    label: "3rd",
    icon: Medal,
  },
];
const podiumOrder = [1, 0, 2];

const Confetti = () => {
  const pieces = Array.from({ length: 24 });
  const colors = [
    "hsl(348 100% 60%)",
    "hsl(43 96% 58%)",
    "hsl(142 71% 50%)",
    "hsl(280 100% 60%)",
    "hsl(220 100% 60%)",
  ];
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {pieces.map((_, i) => {
        const tx = (Math.random() - 0.5) * 600;
        const ty = (Math.random() - 0.2) * 500 + 100;
        const delay = Math.random() * 0.4;
        const size = 6 + Math.random() * 8;
        const color = colors[i % colors.length];
        return (
          <span
            key={i}
            className="absolute left-1/2 top-1/2 rounded-sm"
            style={{
              width: size,
              height: size * 0.4,
              background: color,
              ["--tx" as string]: `${tx}px`,
              ["--ty" as string]: `${ty}px`,
              animation: `confetti-burst 1.4s cubic-bezier(0.2, 0.6, 0.4, 1) ${delay}s forwards`,
            }}
          />
        );
      })}
    </div>
  );
};

export const ResultsScreen = ({ results, totalVoters, onRestart }: Props) => {
  const winner = results[0];
  const top3 = results.slice(0, 3);
  const noWinner = !winner || winner.score === 0;
  const maxScore = Math.max(...results.map((r) => r.score), 1);

  // Edge case: nobody liked anything
  if (noWinner) {
    return (
      <div className="min-h-screen px-5 py-6 sm:py-10 flex flex-col">
        <header className="flex items-center justify-between mb-8 animate-fade-in max-w-2xl mx-auto w-full">
          <Logo size="sm" />
        </header>
        <div className="flex-1 grid place-items-center">
          <div className="text-center max-w-md animate-scale-in">
            <div className="h-20 w-20 mx-auto mb-6 rounded-full glass grid place-items-center">
              <Frown className="h-10 w-10 text-muted-foreground" />
            </div>
            <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight mb-3">
              No matches this round
            </h1>
            <p className="text-muted-foreground mb-8">
              Nobody liked any of the movies. Try a different vibe!
            </p>
            <Button
              onClick={onRestart}
              size="lg"
              className="h-14 px-8 bg-gradient-primary hover:opacity-95 shadow-glow rounded-xl"
            >
              <RotateCcw className="h-5 w-5 mr-1" />
              Try again
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen px-5 py-6 sm:py-10">
      <div className="max-w-2xl mx-auto">
        <header className="flex items-center justify-between mb-8 animate-fade-in">
          <Logo size="sm" />
          <Button
            variant="ghost"
            size="sm"
            onClick={onRestart}
            className="text-muted-foreground hover:text-foreground gap-1.5"
          >
            <RotateCcw className="h-4 w-4" />
            New round
          </Button>
        </header>

        {/* Winner banner */}
        <section className="mb-10 animate-scale-in">
          <div className="text-center mb-5 relative">
            <Confetti />
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent/10 border border-accent/30 mb-3">
              <Trophy className="h-3.5 w-3.5 text-accent" />
              <span className="text-xs font-bold uppercase tracking-widest text-accent">
                Winner
              </span>
            </div>
            <h1 className="text-4xl sm:text-6xl font-semibold tracking-tight leading-[1.05]">
              <span className="text-gradient-gold">{winner.movie.title}</span>
            </h1>
            <p className="text-muted-foreground mt-3 text-sm">
              {winner.score} of {totalVoters} {totalVoters === 1 ? "vote" : "votes"} ·{" "}
              {winner.movie.year} · {winner.movie.director}
            </p>
          </div>

          <div className="relative rounded-3xl overflow-hidden shadow-gold border border-accent/30 aspect-video sm:aspect-[21/9] group">
            <img
              src={winner.movie.backdrop || winner.movie.poster}
              alt={winner.movie.title}
              className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-overlay" />
            <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-6 flex items-end justify-between gap-4">
              <div className="space-y-2">
                <div className="flex flex-wrap gap-1.5">
                  {winner.movie.genre.map((g) => (
                    <span
                      key={g}
                      className="px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wider rounded-full bg-accent/30 text-accent border border-accent/40 backdrop-blur-sm"
                    >
                      {g}
                    </span>
                  ))}
                </div>
                <div className="flex flex-wrap gap-1">
                  {winner.voters.map((v) => (
                    <span
                      key={v}
                      className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-success/20 text-success border border-success/30 backdrop-blur-sm"
                    >
                      ❤ {v}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-background/70 backdrop-blur-md border border-border shrink-0">
                <Star className="h-3.5 w-3.5 fill-accent text-accent" />
                <span className="text-sm font-bold">{winner.movie.rating.toFixed(1)}</span>
              </div>
            </div>
          </div>
        </section>

        {/* Podium */}
        {top3.length > 0 && (
          <section className="mb-10 animate-fade-in" style={{ animationDelay: "150ms" }}>
            <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-5 text-center">
              Top 3 podium
            </h2>
            <div className="grid grid-cols-3 gap-3 sm:gap-4 items-end">
              {podiumOrder.map((rankIdx) => {
                const item = top3[rankIdx];
                if (!item) return <div key={rankIdx} />;
                const cfg = podiumStyles[rankIdx];
                const Icon = cfg.icon;
                return (
                  <div key={item.movie.id} className="flex flex-col items-center group">
                    <div className="relative mb-3">
                      <div className="aspect-[2/3] w-full max-w-[110px] sm:max-w-[130px] rounded-xl overflow-hidden shadow-card-cinema border border-border transition-spring group-hover:scale-105 group-hover:-translate-y-1">
                        <img
                          src={item.movie.poster}
                          alt={item.movie.title}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      {rankIdx === 0 && (
                        <Crown className="absolute -top-5 left-1/2 -translate-x-1/2 h-7 w-7 text-accent fill-accent drop-shadow-lg animate-float" />
                      )}
                    </div>
                    <p className="text-xs sm:text-sm font-semibold text-center line-clamp-2 mb-1 px-1">
                      {item.movie.title}
                    </p>
                    <p className="text-[11px] text-muted-foreground mb-2">
                      {item.score} {item.score === 1 ? "vote" : "votes"}
                    </p>
                    <div
                      className={`${cfg.height} ${cfg.bg} ${cfg.glow} w-full rounded-t-xl flex items-start justify-center pt-2 gap-1`}
                    >
                      <Icon className={`h-4 w-4 ${cfg.text}`} />
                      <span className={`text-sm font-bold ${cfg.text}`}>{cfg.label}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* Score breakdown */}
        <section className="animate-fade-in" style={{ animationDelay: "300ms" }}>
          <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">
            Score breakdown
          </h2>
          <div className="space-y-2.5">
            {results.map((r, i) => {
              const pct = (r.score / maxScore) * 100;
              return (
                <div
                  key={r.movie.id}
                  className="glass rounded-2xl p-3 sm:p-4 flex items-center gap-3 sm:gap-4 hover:border-primary/40 hover:scale-[1.01] transition-spring"
                >
                  <span className="w-6 text-center text-sm font-bold text-muted-foreground tabular-nums shrink-0">
                    {i + 1}
                  </span>
                  <div className="h-14 w-10 sm:h-16 sm:w-12 rounded-md overflow-hidden shrink-0 border border-border">
                    <img
                      src={r.movie.poster}
                      alt={r.movie.title}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{r.movie.title}</p>
                    {r.voters.length > 0 ? (
                      <div className="flex flex-wrap gap-1 mt-1">
                        {r.voters.map((v) => (
                          <span
                            key={v}
                            className="text-[10px] px-1.5 py-0.5 rounded-md bg-success/15 text-success border border-success/25"
                          >
                            {v}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-[11px] text-muted-foreground mt-0.5">No votes</p>
                    )}
                    <div className="mt-2 h-1.5 rounded-full bg-secondary overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-700 ${
                          i === 0 ? "bg-gradient-gold" : "bg-gradient-primary"
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-lg font-bold tabular-nums">{r.score}</p>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider">
                      / {totalVoters}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <div className="mt-10 text-center">
          <Button
            onClick={onRestart}
            size="lg"
            className="h-14 px-8 bg-gradient-primary hover:opacity-95 hover:scale-[1.02] active:scale-[0.98] shadow-glow font-semibold rounded-xl transition-spring"
          >
            <RotateCcw className="h-5 w-5 mr-1" />
            Play another round
          </Button>
        </div>
      </div>
    </div>
  );
};
