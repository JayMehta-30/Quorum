import { useMemo, useState } from "react";
import { StartScreen } from "@/components/StartScreen";
import { VotingScreen } from "@/components/VotingScreen";
import { ResultsScreen, type MovieScore } from "@/components/ResultsScreen";
import { HandoffScreen } from "@/components/HandoffScreen";
import { AuroraBackground } from "@/components/AuroraBackground";
import { MOVIES, type Movie } from "@/data/movies";

type Stage = "start" | "handoff" | "voting" | "results";

const Index = () => {
  const [stage, setStage] = useState<Stage>("start");
  const [players, setPlayers] = useState<string[]>([]);
  const [genres, setGenres] = useState<string[]>([]);
  const [playerIdx, setPlayerIdx] = useState(0);
  // votes[playerName] = Set of liked movieIds
  const [votes, setVotes] = useState<Record<string, Set<string>>>({});

  const filteredMovies: Movie[] = useMemo(() => {
    if (genres.length === 0) return MOVIES;
    const filtered = MOVIES.filter((m) => m.genre.some((g) => genres.includes(g)));
    return filtered.length >= 3 ? filtered : MOVIES;
  }, [genres]);

  const results: MovieScore[] = useMemo(() => {
    return filteredMovies
      .map((movie) => {
        const voters = players.filter((p) => votes[p]?.has(movie.id));
        return { movie, score: voters.length, voters };
      })
      .sort((a, b) => b.score - a.score || b.movie.rating - a.movie.rating);
  }, [filteredMovies, players, votes]);

  const startGame = (names: string[], gs: string[]) => {
    setPlayers(names);
    setGenres(gs);
    setPlayerIdx(0);
    setVotes(Object.fromEntries(names.map((n) => [n, new Set<string>()])));
    setStage("handoff");
  };

  const recordVote = (movieId: string, liked: boolean) => {
    if (!liked) return;
    const current = players[playerIdx];
    setVotes((prev) => {
      const next = { ...prev };
      const set = new Set(next[current] ?? []);
      set.add(movieId);
      next[current] = set;
      return next;
    });
  };

  const finishCurrentPlayer = () => {
    const next = playerIdx + 1;
    if (next >= players.length) {
      setStage("results");
    } else {
      setPlayerIdx(next);
      setStage("handoff");
    }
  };

  const restart = () => {
    setPlayers([]);
    setGenres([]);
    setVotes({});
    setPlayerIdx(0);
    setStage("start");
  };

  return (
    <>
      <AuroraBackground />
      <div key={stage + playerIdx} className="animate-fade-in">
        {stage === "start" && <StartScreen onStart={startGame} />}

        {stage === "handoff" && players[playerIdx] && (
          <HandoffScreen
            nextPlayer={players[playerIdx]}
            playerNumber={playerIdx + 1}
            totalPlayers={players.length}
            onReady={() => setStage("voting")}
          />
        )}

        {stage === "voting" && players[playerIdx] && (
          <VotingScreen
            movies={filteredMovies}
            player={players[playerIdx]}
            playerNumber={playerIdx + 1}
            totalPlayers={players.length}
            onVote={recordVote}
            onComplete={finishCurrentPlayer}
            onBack={restart}
          />
        )}

        {stage === "results" && (
          <ResultsScreen results={results} totalVoters={players.length} onRestart={restart} />
        )}
      </div>
    </>
  );
};

export default Index;
