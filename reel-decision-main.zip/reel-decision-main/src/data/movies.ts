export type Movie = {
  id: string;
  title: string;
  year: number;
  genre: string[];
  runtime: string;
  rating: number;
  director: string;
  overview: string;
  poster: string;
  backdrop: string;
};

const img = (path: string) => `https://image.tmdb.org/t/p/w780${path}`;

export const MOVIES: Movie[] = [
  {
    id: "1",
    title: "Dune: Part Two",
    year: 2024,
    genre: ["Sci-Fi", "Adventure"],
    runtime: "2h 46m",
    rating: 8.5,
    director: "Denis Villeneuve",
    overview:
      "Paul Atreides unites with the Fremen to wage war against the conspirators who destroyed his family.",
    poster: img("/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg"),
    backdrop: img("/8b8R8l88Qje9dn9OE8PY05Nxl1X.jpg"),
  },
  {
    id: "2",
    title: "Oppenheimer",
    year: 2023,
    genre: ["Drama", "History"],
    runtime: "3h 0m",
    rating: 8.3,
    director: "Christopher Nolan",
    overview:
      "The story of J. Robert Oppenheimer's role in the development of the atomic bomb during World War II.",
    poster: img("/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg"),
    backdrop: img("/fm6KqXpk3M2HVveHwCrBSSBaO0V.jpg"),
  },
  {
    id: "3",
    title: "Interstellar",
    year: 2014,
    genre: ["Sci-Fi", "Drama"],
    runtime: "2h 49m",
    rating: 8.7,
    director: "Christopher Nolan",
    overview:
      "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
    poster: img("/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg"),
    backdrop: img("/pbrkL804c8yAv3zBZR4QPEafpAR.jpg"),
  },
  {
    id: "4",
    title: "The Batman",
    year: 2022,
    genre: ["Crime", "Mystery"],
    runtime: "2h 56m",
    rating: 7.8,
    director: "Matt Reeves",
    overview:
      "When a sadistic serial killer begins murdering political figures in Gotham, Batman investigates the city's hidden corruption.",
    poster: img("/74xTEgt7R36Fpooo50r9T25onhq.jpg"),
    backdrop: img("/b0PlSFdDwbyK0cf5RxwDpaOJQvQ.jpg"),
  },
  {
    id: "5",
    title: "Everything Everywhere All at Once",
    year: 2022,
    genre: ["Action", "Comedy", "Sci-Fi"],
    runtime: "2h 19m",
    rating: 8.1,
    director: "Daniels",
    overview:
      "A middle-aged Chinese immigrant is swept up into an insane adventure in which she alone can save existence.",
    poster: img("/w3LxiVYdWWRvEVdn5RYq6jIqkb1.jpg"),
    backdrop: img("/nGxUxi3PfXDRm7Vg95VBNgNM8yc.jpg"),
  },
  {
    id: "6",
    title: "Spider-Man: Across the Spider-Verse",
    year: 2023,
    genre: ["Animation", "Action"],
    runtime: "2h 20m",
    rating: 8.6,
    director: "Joaquim Dos Santos",
    overview:
      "Miles Morales catapults across the Multiverse, where he encounters a team of Spider-People charged with protecting its existence.",
    poster: img("/8Vt6mWEReuy4Of61Lnj5Xj704m8.jpg"),
    backdrop: img("/4HodYYKEIsGOdinkGi2Ucfxbf6F.jpg"),
  },
  {
    id: "7",
    title: "Parasite",
    year: 2019,
    genre: ["Thriller", "Drama"],
    runtime: "2h 12m",
    rating: 8.5,
    director: "Bong Joon-ho",
    overview:
      "Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan.",
    poster: img("/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg"),
    backdrop: img("/TU9NIjwzjoKPwQHoHshkFcQUCG.jpg"),
  },
  {
    id: "8",
    title: "Blade Runner 2049",
    year: 2017,
    genre: ["Sci-Fi", "Mystery"],
    runtime: "2h 44m",
    rating: 8.0,
    director: "Denis Villeneuve",
    overview:
      "Young Blade Runner K's discovery of a long-buried secret leads him on a quest to find a former Blade Runner who's been missing for thirty years.",
    poster: img("/gajva2L0rPYkEWjzgFlBXCAVBE5.jpg"),
    backdrop: img("/ilRyazdMJwN05exqhwK4tMKBYZs.jpg"),
  },
  {
    id: "9",
    title: "The Grand Budapest Hotel",
    year: 2014,
    genre: ["Comedy", "Drama"],
    runtime: "1h 39m",
    rating: 8.1,
    director: "Wes Anderson",
    overview:
      "A legendary concierge at a famous European hotel between the wars becomes a trusted friend and mentor to a young employee.",
    poster: img("/eWdyYQreja6JGCzqHWXpWHDrrPo.jpg"),
    backdrop: img("/xnRPoFI7wzOWISuJWtvjcjbxh84.jpg"),
  },
  {
    id: "10",
    title: "Whiplash",
    year: 2014,
    genre: ["Drama", "Music"],
    runtime: "1h 47m",
    rating: 8.5,
    director: "Damien Chazelle",
    overview:
      "A promising young drummer enrolls at a cut-throat music conservatory where his dreams of greatness are mentored by a brutal instructor.",
    poster: img("/7fn624j5lj3xTme2SgiLCeuedmO.jpg"),
    backdrop: img("/6bbZ6XyvgfjhQwbplnUh1LSj1ky.jpg"),
  },
  {
    id: "11",
    title: "La La Land",
    year: 2016,
    genre: ["Romance", "Musical"],
    runtime: "2h 8m",
    rating: 8.0,
    director: "Damien Chazelle",
    overview:
      "While navigating their careers in Los Angeles, a pianist and an actress fall in love while attempting to reconcile their aspirations.",
    poster: img("/uDO8zWDhfWwoFdKS4fzkUJt0Rf0.jpg"),
    backdrop: img("/nlPCdZlHtRNcF6C9hzUH4ebmV1w.jpg"),
  },
  {
    id: "12",
    title: "Mad Max: Fury Road",
    year: 2015,
    genre: ["Action", "Adventure"],
    runtime: "2h 0m",
    rating: 8.1,
    director: "George Miller",
    overview:
      "In a post-apocalyptic wasteland, a woman rebels against a tyrannical ruler in search for her homeland with the aid of a group of female prisoners.",
    poster: img("/hA2ple9q4qnwxp3hKVNhroipsir.jpg"),
    backdrop: img("/gqrnQA6Xppdl8vIb2eJc58VC1tW.jpg"),
  },
  {
    id: "13",
    title: "Get Out",
    year: 2017,
    genre: ["Horror", "Thriller"],
    runtime: "1h 44m",
    rating: 7.7,
    director: "Jordan Peele",
    overview:
      "A young African-American visits his white girlfriend's parents for the weekend, where his simmering uneasiness about their reception eventually reaches a boiling point.",
    poster: img("/tFXcEccSQMf3lfhfXKSU9iRBpa3.jpg"),
    backdrop: img("/dWp5tHXbPxqyTRfwvxptD9ppzMW.jpg"),
  },
  {
    id: "14",
    title: "The Social Network",
    year: 2010,
    genre: ["Drama", "Biography"],
    runtime: "2h 0m",
    rating: 7.8,
    director: "David Fincher",
    overview:
      "As Harvard student Mark Zuckerberg creates the social networking site that would become known as Facebook, he is sued by the twins who claimed he stole their idea.",
    poster: img("/n0ybibhJtQ5icDqTp8eRytcIHJx.jpg"),
    backdrop: img("/n4nspyN2YDmiUd0HxrbWypGiLBM.jpg"),
  },
  {
    id: "15",
    title: "Arrival",
    year: 2016,
    genre: ["Sci-Fi", "Drama"],
    runtime: "1h 56m",
    rating: 7.9,
    director: "Denis Villeneuve",
    overview:
      "A linguist works with the military to communicate with alien lifeforms after twelve mysterious spacecraft appear around the world.",
    poster: img("/x2FJsf1ElAgr63Y3PNPtJrcmpoe.jpg"),
    backdrop: img("/yIZ1xendyqKvY3FGeeUYUd5X9Mm.jpg"),
  },
  {
    id: "16",
    title: "John Wick: Chapter 4",
    year: 2023,
    genre: ["Action", "Thriller"],
    runtime: "2h 49m",
    rating: 7.7,
    director: "Chad Stahelski",
    overview:
      "John Wick uncovers a path to defeating The High Table. But before he can earn his freedom, Wick must face off against a new enemy with powerful alliances.",
    poster: img("/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg"),
    backdrop: img("/7I6VUdPj6tQECNHdviJkUHD2u89.jpg"),
  },
];

export const ALL_GENRES = Array.from(
  new Set(MOVIES.flatMap((m) => m.genre))
).sort();
