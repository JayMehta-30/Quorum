import { StartScreen } from "@/components/StartScreen";
import { VotingScreen } from "@/components/VotingScreen";
import { ResultsScreen } from "@/components/ResultsScreen";
import { HandoffScreen } from "@/components/HandoffScreen";
import { CountdownScreen } from "@/components/CountdownScreen";
import { AuroraBackground } from "@/components/AuroraBackground";
import { MOVIES } from "@/data/movies";
import { useVotingSession } from "@/hooks/useVotingSession";

const Index = () => {
  const {
    players,
    currentUserIndex,
    currentPlayer,
    phase,
    filteredMovies,
    results,
    startSession,
    markReady,
    handleVote,
    nextUserFlow,
    triggerResults,
    restart,
  } = useVotingSession(MOVIES);

  return (
    <>
      <AuroraBackground />
      <div key={phase + currentUserIndex} className="animate-fade-in">
        {phase === "start" && (
          <StartScreen onStart={startSession} />
        )}

        {phase === "handoff" && currentPlayer && (
          <HandoffScreen
            nextPlayer={currentPlayer}
            playerNumber={currentUserIndex + 1}
            totalPlayers={players.length}
            onReady={markReady}
          />
        )}

        {phase === "voting" && currentPlayer && (
          <VotingScreen
            movies={filteredMovies}
            player={currentPlayer}
            playerNumber={currentUserIndex + 1}
            totalPlayers={players.length}
            onVote={handleVote}
            onComplete={nextUserFlow}
            onBack={restart}
          />
        )}

        {phase === "countdown" && (
          <CountdownScreen onComplete={triggerResults} />
        )}

        {phase === "results" && (
          <ResultsScreen
            results={results}
            totalVoters={players.length}
            players={players}
            onRestart={restart}
          />
        )}
      </div>
    </>
  );
};

export default Index;
