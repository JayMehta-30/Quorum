import { useCallback, useRef, useState } from "react";
import type { VoteValue } from "./useVotingSession";

interface SwipeState {
  dx: number;
  dy: number;
  dragging: boolean;
}

interface UseSwipeOptions {
  threshold?: number; // px before a swipe is committed
  onSwipe: (vote: VoteValue) => void;
}

/**
 * Pure pointer-event swipe handler (no external libraries).
 * Right → "yes", Left → "no", Up → "love"
 * Returns transform/opacity values for the card + pointer event handlers.
 */
export function useSwipe({ threshold = 80, onSwipe }: UseSwipeOptions) {
  const startRef = useRef<{ x: number; y: number } | null>(null);
  const [swipe, setSwipe] = useState<SwipeState>({ dx: 0, dy: 0, dragging: false });

  const onPointerDown = useCallback((e: React.PointerEvent) => {
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    startRef.current = { x: e.clientX, y: e.clientY };
    setSwipe({ dx: 0, dy: 0, dragging: true });
  }, []);

  const onPointerMove = useCallback((e: React.PointerEvent) => {
    if (!startRef.current) return;
    const dx = e.clientX - startRef.current.x;
    const dy = e.clientY - startRef.current.y;
    setSwipe({ dx, dy, dragging: true });
  }, []);

  const onPointerUp = useCallback(
    (e: React.PointerEvent) => {
      if (!startRef.current) return;
      const dx = e.clientX - startRef.current.x;
      const dy = e.clientY - startRef.current.y;
      startRef.current = null;

      const absX = Math.abs(dx);
      const absY = Math.abs(dy);

      if (absY > threshold && absY > absX && dy < 0) {
        // up swipe → love
        onSwipe("love");
      } else if (absX > threshold && absX >= absY) {
        onSwipe(dx > 0 ? "yes" : "no");
      } else {
        // snap back
        setSwipe({ dx: 0, dy: 0, dragging: false });
      }
    },
    [threshold, onSwipe]
  );

  const onPointerCancel = useCallback(() => {
    startRef.current = null;
    setSwipe({ dx: 0, dy: 0, dragging: false });
  }, []);

  // Derived transform values
  const rotation = swipe.dx * 0.12; // degrees proportional to horizontal drag
  const dragTransform =
    swipe.dragging && (swipe.dx !== 0 || swipe.dy !== 0)
      ? `translate(${swipe.dx}px, ${swipe.dy}px) rotate(${rotation}deg)`
      : undefined;

  // Swipe direction hints
  const absX = Math.abs(swipe.dx);
  const absY = Math.abs(swipe.dy);
  const HINT = 40; // px before showing stamp hint
  const hintRight = swipe.dragging && swipe.dx > HINT && absX >= absY;
  const hintLeft = swipe.dragging && swipe.dx < -HINT && absX >= absY;
  const hintUp = swipe.dragging && swipe.dy < -HINT && absY > absX;

  // Opacity dims slightly as you drag far
  const dragOpacity =
    swipe.dragging && absX > 20
      ? Math.max(0.6, 1 - absX / 400)
      : undefined;

  return {
    swipeHandlers: { onPointerDown, onPointerMove, onPointerUp, onPointerCancel },
    dragTransform,
    dragOpacity,
    hintRight,
    hintLeft,
    hintUp,
    isDragging: swipe.dragging,
  };
}
