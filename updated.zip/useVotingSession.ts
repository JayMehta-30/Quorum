import { useMemo, useState } from "react";
import type { Movie } from "@/data/movies";

export type VoteValue = "yes" | "no" | "love";
export type Phase = "start" | "handoff" | "voting" | "countdown" | "results";

// votes[userName][movieId] = VoteValue
export type VotesMap = Record<string, Record<string, VoteValue>>;

export interface MovieScore {
  movie: Movie;
  score: number;
  voters: string[];           // users who voted yes or love
  voteDetail: Record<string, VoteValue>;
}

const WEIGHTS: Record<VoteValue, number> = { love: 3, yes: 1, no: 0 };

export function calculateResults(
  movies: Movie[],
  votes: VotesMap,
  players: string[]
): MovieScore[] {
  return movies
    .map((movie) => {
      let score = 0;
      const voters: string[] = [];
      const voteDetail: Record<string, VoteValue> = {};
      players.forEach((p) => {
        const v = votes[p]?.[movie.id];
        if (v) {
          voteDetail[p] = v;
          score += WEIGHTS[v];
          if (v === "yes" || v === "love") voters.push(p);
        }
      });
      return { movie, score, voters, voteDetail };
    })
    .sort((a, b) => b.score - a.score || b.movie.rating - a.movie.rating);
}

export function useVotingSession(allMovies: Movie[]) {
  const [players, setPlayers] = useState<string[]>([]);
  const [genres, setGenres] = useState<string[]>([]);
  const [currentUserIndex, setCurrentUserIndex] = useState(0);
  const [votes, setVotes] = useState<VotesMap>({});
  // tracks which users have confirmed "ready" on the handoff screen
  const [readySet, setReadySet] = useState<Set<number>>(new Set());
  const [phase, setPhase] = useState<Phase>("start");

  // Genre-filtered movie list
  const filteredMovies: Movie[] = useMemo(() => {
    if (genres.length === 0) return allMovies;
    const filtered = allMovies.filter((m) => m.genre.some((g) => genres.includes(g)));
    return filtered.length >= 3 ? filtered : allMovies;
  }, [allMovies, genres]);

  // ---------- actions ----------

  const startSession = (names: string[], gs: string[]) => {
    setPlayers(names);
    setGenres(gs);
    setCurrentUserIndex(0);
    setVotes(Object.fromEntries(names.map((n) => [n, {}])));
    setReadySet(new Set());
    setPhase("handoff");
  };

  /** Mark current user as ready → start their voting turn */
  const markReady = () => {
    setReadySet((prev) => new Set([...prev, currentUserIndex]));
    setPhase("voting");
  };

  /**
   * Record a vote for the current user.
   * Strict isolation: only mutates current user's sub-object.
   */
  const handleVote = (movieId: string, value: VoteValue) => {
    const currentUser = players[currentUserIndex];
    if (!currentUser) return;
    setVotes((prev) => ({
      ...prev,
      [currentUser]: { ...prev[currentUser], [movieId]: value },
    }));
  };

  /**
   * Move to next user (handoff), or trigger countdown when all users done.
   */
  const nextUserFlow = () => {
    const next = currentUserIndex + 1;
    if (next >= players.length) {
      setPhase("countdown");
    } else {
      setCurrentUserIndex(next);
      setPhase("handoff");
    }
  };

  const triggerResults = () => setPhase("results");

  const restart = () => {
    setPlayers([]);
    setGenres([]);
    setVotes({});
    setReadySet(new Set());
    setCurrentUserIndex(0);
    setPhase("start");
  };

  // ---------- derived ----------

  const results = useMemo(
    () => calculateResults(filteredMovies, votes, players),
    [filteredMovies, votes, players]
  );

  const currentPlayer = players[currentUserIndex] ?? "";

  return {
    players,
    genres,
    currentUserIndex,
    currentPlayer,
    votes,
    phase,
    filteredMovies,
    results,
    startSession,
    markReady,
    handleVote,
    nextUserFlow,
    triggerResults,
    restart,
  };
}
