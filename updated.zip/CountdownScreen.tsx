import { useEffect, useState } from "react";
import { Trophy } from "lucide-react";

interface Props {
  onComplete: () => void;
}

export const CountdownScreen = ({ onComplete }: Props) => {
  const [count, setCount] = useState(5);

  useEffect(() => {
    if (count <= 0) {
      onComplete();
      return;
    }
    const id = window.setTimeout(() => setCount((c) => c - 1), 1000);
    return () => clearTimeout(id);
  }, [count, onComplete]);

  return (
    <div className="min-h-screen flex items-center justify-center px-6 py-10 animate-fade-in">
      <div className="max-w-md w-full text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass mb-10">
          <span className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
            Tallying votes…
          </span>
        </div>

        <div className="relative mb-8 animate-scale-in">
          <div className="h-40 w-40 mx-auto rounded-full bg-gradient-gold grid place-items-center shadow-gold animate-pulse-glow">
            <span
              key={count}
              className="text-7xl font-semibold text-accent-foreground animate-scale-in"
            >
              {count}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-center gap-2 text-muted-foreground">
          <Trophy className="h-4 w-4 text-accent" />
          <p className="text-sm">Results incoming…</p>
        </div>
      </div>
    </div>
  );
};
