import { useState } from "react";
import { Heart, X, Info, Trophy, ArrowLeft, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { MovieCard } from "./MovieCard";
import { Logo } from "./Logo";
import { useSwipe } from "@/hooks/useSwipe";
import type { Movie } from "@/data/movies";
import type { VoteValue } from "@/hooks/useVotingSession";

interface Props {
  movies: Movie[];
  player: string;
  playerNumber: number;
  totalPlayers: number;
  onVote: (movieId: string, value: VoteValue) => void;
  onComplete: () => void;
  onBack: () => void;
}

type FlyDir = null | "left" | "right" | "up";

/** Top card with pointer-event swipe wired in */
const SwipeableCard = ({
  movie,
  baseStyle,
  className,
  onSwipeCommit,
  flyDir,
}: {
  movie: Movie;
  baseStyle: React.CSSProperties;
  className: string;
  onSwipeCommit: (v: VoteValue) => void;
  flyDir: FlyDir;
}) => {
  const { swipeHandlers, dragTransform, dragOpacity, hintRight, hintLeft, hintUp, isDragging } =
    useSwipe({ onSwipe: onSwipeCommit });

  const computedTransform = flyDir
    ? flyDir === "right"
      ? "translateX(140%) rotate(18deg)"
      : flyDir === "left"
      ? "translateX(-140%) rotate(-18deg)"
      : "translateY(-160%) rotate(-6deg)"
    : dragTransform;

  const computedOpacity = flyDir ? 0 : dragOpacity;

  const transition = flyDir
    ? "transform 320ms cubic-bezier(0.4,0,0.2,1), opacity 320ms ease-out"
    : isDragging
    ? "none"
    : "transform 400ms cubic-bezier(0.34,1.56,0.64,1)";

  return (
    <div className="absolute inset-0" style={{ zIndex: 20 }} {...swipeHandlers}>
      <MovieCard
        movie={movie}
        className={className}
        style={{
          ...baseStyle,
          ...(computedTransform ? { transform: computedTransform } : {}),
          ...(computedOpacity !== undefined ? { opacity: computedOpacity } : {}),
          transition,
        }}
      />
      {(hintRight || flyDir === "right") && (
        <div className="absolute top-10 left-8 z-30 px-5 py-2 rounded-2xl border-4 border-success text-success font-extrabold text-3xl tracking-widest animate-stamp-in pointer-events-none">
          LIKE
        </div>
      )}
      {(hintLeft || flyDir === "left") && (
        <div className="absolute top-10 right-8 z-30 px-5 py-2 rounded-2xl border-4 border-destructive text-destructive font-extrabold text-3xl tracking-widest animate-stamp-in pointer-events-none">
          NOPE
        </div>
      )}
      {(hintUp || flyDir === "up") && (
        <div className="absolute top-10 left-1/2 -translate-x-1/2 z-30 px-5 py-2 rounded-2xl border-4 border-accent text-accent font-extrabold text-2xl tracking-widest animate-stamp-in pointer-events-none whitespace-nowrap">
          LOVE ✨
        </div>
      )}
    </div>
  );
};

export const VotingScreen = ({
  movies,
  player,
  playerNumber,
  totalPlayers,
  onVote,
  onComplete,
  onBack,
}: Props) => {
  const [movieIdx, setMovieIdx] = useState(0);
  const [flying, setFlying] = useState<FlyDir>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const progress = (movieIdx / movies.length) * 100;
  const stack = movies.slice(movieIdx, movieIdx + 3);
  const done = movieIdx >= movies.length;
  const currentMovie = movies[movieIdx];

  const advance = (value: VoteValue) => {
    if (flying || done) return;
    const dir: FlyDir = value === "yes" ? "right" : value === "no" ? "left" : "up";
    setFlying(dir);
    onVote(currentMovie.id, value);
    window.setTimeout(() => {
      const next = movieIdx + 1;
      setMovieIdx(next);
      setFlying(null);
      if (next >= movies.length) {
        window.setTimeout(onComplete, 700);
      }
    }, 320);
  };

  return (
    <div className="min-h-screen flex flex-col px-5 py-6 max-w-md mx-auto">
      {/* Header */}
      <header className="flex items-center justify-between mb-5 animate-fade-in">
        <button
          onClick={onBack}
          className="h-9 w-9 rounded-full grid place-items-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-smooth"
          aria-label="Back to start"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
        <Logo size="sm" />
        <Button
          variant="ghost"
          size="sm"
          onClick={onComplete}
          className="text-muted-foreground hover:text-accent gap-1.5 h-9 px-3"
        >
          <Trophy className="h-4 w-4" />
          Skip
        </Button>
      </header>

      {/* Player + progress */}
      <div className="mb-5 animate-fade-in" style={{ animationDelay: "80ms" }}>
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-full bg-gradient-primary grid place-items-center text-sm font-semibold text-primary-foreground shadow-glow">
              {player.charAt(0).toUpperCase()}
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground leading-none mb-1 uppercase tracking-wider">
                Voting
              </p>
              <p className="text-sm font-semibold leading-none">{player}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-[11px] text-muted-foreground leading-none mb-1 uppercase tracking-wider">
              Movie
            </p>
            <p className="text-sm font-semibold leading-none tabular-nums">
              {Math.min(movieIdx + 1, movies.length)} / {movies.length}
            </p>
          </div>
        </div>
        <Progress value={progress} className="h-1.5 bg-secondary" />
        <p className="text-[11px] text-muted-foreground/70 mt-2 text-center">
          Player {playerNumber} of {totalPlayers}
        </p>
      </div>

      {/* Card stack */}
      <div className="flex-1 flex items-center justify-center min-h-0">
        <div className="relative w-full aspect-[2/3] max-h-[58vh]">
          {done ? (
            <div className="absolute inset-0 rounded-[2rem] glass grid place-items-center text-center p-6 animate-scale-in">
              <div>
                <div className="h-16 w-16 mx-auto mb-4 rounded-full bg-gradient-gold grid place-items-center shadow-gold animate-float">
                  <Trophy className="h-8 w-8 text-accent-foreground" />
                </div>
                <p className="font-semibold mb-1 text-lg">Nice work, {player}!</p>
                <p className="text-sm text-muted-foreground">Tallying votes…</p>
              </div>
            </div>
          ) : (
            <>
              {/* Background stack cards (non-interactive) */}
              {stack
                .slice(1)
                .map((movie, i) => {
                  const depth = i + 1;
                  return (
                    <div
                      key={`${movie.id}-${movieIdx}-bg-${i}`}
                      className="absolute inset-0"
                      style={{ zIndex: 10 - depth }}
                    >
                      <MovieCard
                        movie={movie}
                        style={{
                          transform: `translateY(${depth * -10}px) scale(${1 - depth * 0.04})`,
                          opacity: 1 - depth * 0.2,
                          transition:
                            "transform 400ms cubic-bezier(0.34,1.56,0.64,1), opacity 300ms ease-out",
                        }}
                      />
                    </div>
                  );
                })
                .reverse()}

              {/* Top card — swipeable */}
              {stack[0] && (
                <SwipeableCard
                  key={`${stack[0].id}-${movieIdx}-top`}
                  movie={stack[0]}
                  flyDir={flying}
                  className="animate-scale-in"
                  baseStyle={{}}
                  onSwipeCommit={advance}
                />
              )}
            </>
          )}
        </div>
      </div>

      {/* Action buttons */}
      <div
        className="flex items-center justify-center gap-4 sm:gap-5 mt-6 pt-2 animate-fade-in"
        style={{ animationDelay: "200ms" }}
      >
        <button
          onClick={() => advance("no")}
          disabled={done || !!flying}
          aria-label="Nope"
          className="h-14 w-14 rounded-full glass grid place-items-center text-destructive hover:scale-110 hover:border-destructive/60 hover:bg-destructive/10 active:scale-95 transition-spring shadow-card-cinema disabled:opacity-40 disabled:hover:scale-100"
        >
          <X className="h-6 w-6" strokeWidth={2.5} />
        </button>

        <button
          onClick={() => advance("love")}
          disabled={done || !!flying}
          aria-label="Love"
          title="Love it (or swipe up)"
          className="h-14 w-14 rounded-full bg-gradient-gold grid place-items-center text-accent-foreground hover:scale-110 active:scale-95 transition-spring shadow-gold disabled:opacity-40 disabled:hover:scale-100"
        >
          <Sparkles className="h-6 w-6" strokeWidth={2.5} />
        </button>

        <button
          aria-label="Details"
          disabled={done}
          onClick={() => setDetailsOpen(true)}
          className="h-12 w-12 rounded-full glass grid place-items-center text-primary-glow hover:scale-110 hover:border-primary/60 hover:bg-primary/10 active:scale-95 transition-spring disabled:opacity-40"
        >
          <Info className="h-5 w-5" strokeWidth={2.5} />
        </button>

        <button
          onClick={() => advance("yes")}
          disabled={done || !!flying}
          aria-label="Like"
          className="h-14 w-14 rounded-full bg-gradient-primary grid place-items-center text-primary-foreground hover:scale-110 active:scale-95 transition-spring shadow-glow disabled:opacity-40 disabled:hover:scale-100"
        >
          <Heart className="h-6 w-6 fill-current" strokeWidth={2.5} />
        </button>
      </div>

      <p className="text-[10px] text-muted-foreground/50 text-center mt-3">
        Swipe ← no · → yes · ↑ love
      </p>

      {/* Details modal */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="glass border-border/60 max-w-md">
          {currentMovie && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl font-semibold tracking-tight">
                  {currentMovie.title}
                </DialogTitle>
                <DialogDescription className="text-muted-foreground">
                  {currentMovie.year} · Directed by {currentMovie.director} · {currentMovie.runtime}
                </DialogDescription>
              </DialogHeader>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {currentMovie.genre.map((g) => (
                  <span
                    key={g}
                    className="px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wider rounded-full bg-primary/15 text-primary-glow border border-primary/30"
                  >
                    {g}
                  </span>
                ))}
              </div>
              <p className="text-sm text-foreground/80 leading-relaxed mt-3">
                {currentMovie.overview}
              </p>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};
